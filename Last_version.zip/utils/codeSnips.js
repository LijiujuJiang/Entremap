//remote vs local condition
if (process.env.NODE_ENV === "production") {
} else {
}
